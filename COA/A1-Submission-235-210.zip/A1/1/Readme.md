## Hello World Program
A hello world message should be printed out by a module periodically. 

The module should also print the current timestamp (in clock cycles). Module terminates after 100 clock cycles.

Compile the files from the root folder         
                `iverilog -o a.vvp <verilog code file name.v> <testbenchfilename.v>`

Run the compiled file as                  
                `vvp a.vvp`